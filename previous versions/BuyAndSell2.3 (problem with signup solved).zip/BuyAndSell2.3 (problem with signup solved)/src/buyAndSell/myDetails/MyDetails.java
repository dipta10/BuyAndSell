package buyAndSell.myDetails;

public class MyDetails {
    public static String myUserName;
    
}
