/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package buyAndSell.ui.InUp2;

import buyAndSell.database.DatabaseHandler;
import static buyAndSell.ui.InUp.InUpController.myUserName;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author dipta10
 */
public class InUpController implements Initializable {

    DatabaseHandler handler = DatabaseHandler.getInstance();
    
    @FXML
    private VBox rootPane;
    @FXML
    private JFXTextField userName;
    @FXML
    private JFXPasswordField password;
    @FXML
    private JFXButton close;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
    
    @FXML
    void cancel() {
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.close();
    }

    void loadWindow(String location, String title) {
        try {
            Parent parent = (Parent) FXMLLoader.load(getClass().getResource(location));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(buyAndSell.ui.InUp.InUpController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    void loadWindow(String location, String title, StageStyle style) {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource(location));
            Stage stage = new Stage(style);
            stage.setTitle(title);
            stage.setScene(new Scene(parent));
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(buyAndSell.ui.InUp.InUpController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

    @FXML
    private void signUp(ActionEvent event) {
    }

    @FXML
    private void signIn(ActionEvent event) {
        
        boolean flag = password.getText().isEmpty() || userName.getText().isEmpty();
        if (flag) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Please fill in all the options");
            alert.showAndWait();
            return;
        }
        
        String query = "SELECT * FROM MEMBER";
        ResultSet result = handler.execQuery(query);
        boolean found = false;
        boolean match = false;
        
        try {
            while (result.next()) {
                String id = result.getString("id");
                String pass = result.getString("password");
                System.out.println(id + " " + pass);
                if (id.equals(userName.getText())) {
                    found = true;
                    if (pass.equals(password.getText())) {
                        match = true;
                    }
                }
            }
            if (!found) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("Username '" + userName.getText() + "' not found");
                alert.showAndWait();
            } else if (!match) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText(null);
                alert.setContentText("The password is not correct!!");
                alert.showAndWait();
            } else {
                loadWindow("/buyAndSell/ui/Main/main.fxml", "Sign Up", StageStyle.UNDECORATED);
                cancel();
            }
        } catch (SQLException ex) {
            Logger.getLogger(buyAndSell.ui.InUp.InUpController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
